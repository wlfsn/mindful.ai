const general = {
    listPerPage: 10
};

module.exports = general;