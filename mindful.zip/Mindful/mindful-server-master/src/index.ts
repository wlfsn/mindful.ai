// @ts-nocheck

import express, { Request, Response } from 'express';
import router from './routes/index.routes';

import morgan from 'morgan';
const app = express();


import {authorizationMiddleware} from './auth_service';
import userRegistrationApiKeyMiddleware from './middlewares/userRegistrationApiKeyMiddleware';




app.use(express.json());
// app.use(authorizationMiddleware);

app.use(morgan())


router(app);



app.get('/', async (req: Request, res: Response) => {
    res.json({ message: 'Hello from Express Prisma Boilerplate!' });
});




app.listen(process.env.APP_PORT, () => {
    console.log('Express server is running on port 3000');
});
