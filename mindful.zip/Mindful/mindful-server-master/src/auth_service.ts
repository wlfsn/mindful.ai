// @ts-nocheck


import { auth } from 'express-oauth2-jwt-bearer'
import to from 'await-to-js';
import * as process from "process";


const checkJwt = auth({
    audience: process.env.AUTH0_AUDIENCE,
    issuerBaseURL: process.env.AUTH0_ISSUER_URL,

});

const verifyToken = (req: Express.Request, res: Express.Response) => {
    return new Promise((resolve, reject) => {
        checkJwt(req, res, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
};

export const authorizationMiddleware = async (req: Express.Request, res: Express.Response, next: Function) => {
    const [error,response]= await to(verifyToken(req, res));
    if (error) {
        return res.status(401).send(error.message);
    } else {
        if(typeof req.access === 'undefined'){
            req.access = {};
        }
        req.access.auth0user = req.auth.payload
        next();
    }
}


