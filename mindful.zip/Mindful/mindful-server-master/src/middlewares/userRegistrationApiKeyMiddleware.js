// Middleware to authenticate API key
export default  function userRegistrationApiKeyMiddleware (req, res, next)  {
    const apiKey = req.get('X-API-Key');
    const validApiKey = '6a3cce8d-e7d8-4e84-a62e-6405039b5604';

    if (!apiKey || apiKey !== validApiKey) {
        return res.status(401).json({ message: 'Unauthorized: Invalid API key' });
    }

    next();
};