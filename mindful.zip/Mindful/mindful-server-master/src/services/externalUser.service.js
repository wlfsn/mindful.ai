import prisma from "./db.service";
import helper from "../utils/db.util";
import config from "../configs/general.config";



/*
*
{
id: 'abc123',
tenant: 'my-tenant',
username: 'user1',
password: 'xxxxxxx',
email: 'user1@foo.com',
emailVerified: false,
phoneNumber: '1-000-000-0000',
phoneNumberVerified: false,
user_metadata: { hobby: 'surfing' },
app_metadata: { plan: 'full' }
}
*
* */

async function getByUserId(userId){
    return prisma.externalUser.findUnique({
        where: {
            externalUser: userId
        }
    })
}

async function get(id){
    return prisma.externalUser.findUnique({
        where: {
            id: id
        }
    })
}

async function create(body,provider='auth0'){
    if(provider === 'auth0') {
        const {id} = body;
        return prisma.ExternalUser.create({
            data: {
                externalUserId: id,
                provider: provider,
            }
        });
    }
}


module.exports = {
    get,
    create,
}