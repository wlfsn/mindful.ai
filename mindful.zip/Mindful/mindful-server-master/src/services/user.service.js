import prisma from "./db.service";
import helper from "../utils/db.util";
import config from "../configs/general.config";

async function get(userId){

}

async function create(body){

    console.log(body);
    const { id } = body;

    return prisma.user.create({
        data: {
            externalUser: 15,
            status: "active"
        }
    });



    return prisma.user.create({
        data: {
            externalUser: id,
            status: "active"
        }
    });
}

async function update(id, user){

}

async function remove(id){

}

module.exports = {
    get,
    create,
    update,
    remove
}