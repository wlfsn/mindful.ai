const user = require('../services/user.service');
const externalUser = require('../services/externalUser.service');

async function get(req, res, next) {
    try {
        res.json(await user.get(req.query.page));
    } catch (err) {
        console.error(`Error while getting programming languages`, err.message);
        next(err);
    }
}
async function create(req, res, next) {
    try {
        res.json(await user.create(req.body));
    } catch (err) {
        console.error(`Error while creating user`, err.message);

        return res.status(500).json({ message: err.message});

    }
}

async function update(req, res, next) {
    try {
        res.json(await user.update(req.params.id, req.body));
    } catch (err) {
        console.error(`Error while updating programming language`, err.message);
        next(err);
    }
}

async function remove(req, res, next) {
    try {
        res.json(await user.remove(req.params.id));
    } catch (err) {
        console.error(`Error while deleting programming language`, err.message);
        next(err);
    }
}


module.exports = {
    get,
    create,
    update,
    remove
};