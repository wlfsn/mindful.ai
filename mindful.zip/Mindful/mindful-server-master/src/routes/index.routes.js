import userRoute from './user.route';

export default function(app) {
    app.use('/api/v1/user', userRoute);
}



