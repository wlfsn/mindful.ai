import { createRoot } from 'react-dom/client';
import App from './App';
import { ConfigProvider, theme } from 'antd';
import store from './store';
import { Provider } from 'react-redux';
// import { setLoggedIn } from './reducers/appSlice';
import AuthProvider from "./providers/authProvider";

const container = document.getElementById('root') as HTMLElement;
const root = createRoot(container);
root.render(
  <Provider store={store}>
    <ConfigProvider theme={{ algorithm: theme.defaultAlgorithm }}>
      <AuthProvider>
      <App />
      </AuthProvider>
    </ConfigProvider>
  </Provider>
);
// calling IPC exposed from preload script

// window.electron.ipcRenderer.sendMessage('loggedIn', ['test']);
// window.electron.ipcRenderer.once('loggedIn', (arg) => {
//   // eslint-disable-next-line no-console
//   console.log(arg);
// });
