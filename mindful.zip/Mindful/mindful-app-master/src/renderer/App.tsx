import { useCallback } from 'react';
import type { Container, Engine } from 'tsparticles-engine';
import Particles from 'react-tsparticles';
import { loadFull } from 'tsparticles';
import { Button } from 'antd';
import { useSelector, useDispatch } from 'react-redux';
import particleOptions from './utils/particleOptions';
import { setLoggedIn } from './reducers/appSlice';
import  AppLayout  from './containers/AppLayout'


import './App.css';
import { ipcRenderer } from 'electron';

const { loadPolygonMaskPlugin } = require('tsparticles-plugin-polygon-mask');

export default function App() {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.app.loggedIn);

  const particlesInit = useCallback(async (engine: Engine) => {
    console.log(engine);

    await loadFull(engine);
    await loadPolygonMaskPlugin(engine);
  }, []);

  const particlesLoaded = useCallback(
    async (container: Container | undefined) => {
      await console.log(container);
    },
    []
  );

  const handleLogIn = () => {
    window.electron.ipcRenderer.invoke('login', ['test']);
    dispatch(setLoggedIn(true));
  };

  const handleLogOut = () => {
    window.electron.ipcRenderer.invoke('logout', ['test']);
    dispatch(setLoggedIn(false));
  };


  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      {isLoggedIn ? (
        <div>
          <Particles
            id="tsparticles"
            init={particlesInit}
            loaded={particlesLoaded}
            options={particleOptions}
          />

          <div
            className="text-logo"
            style={{
              position: 'absolute',
              bottom: '25%',
              left: '50%',
              zIndex: 1,
              color: '#fff',
              transform: 'translateX(-41%)',
              opacity: 0.9,
            }}
          >
            <div onClick={handleLogOut}>mindful</div>
          </div>
        </div>
      ) : (
        <AppLayout/>
      )}
    </div>
  );
}
