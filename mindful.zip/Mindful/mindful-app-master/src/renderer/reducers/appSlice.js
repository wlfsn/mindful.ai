import { createSlice } from '@reduxjs/toolkit';

export const appSlice = createSlice({
  name: 'app',
  initialState: {
    online: false,
    loggedIn: false,
    authToken: null,
    requiresICloudMFA: false,
  },
  reducers: {
    setOnline: (state, action) => {
      state.online = action.payload;
    },
    setLoggedIn: (state, action) => {
      console.log('setLoggedIn', action.payload);

      state.loggedIn = action.payload;
    },
    setAuthToken: (state, action) => {
      state.authToken = action.payload;
    },
    setRequiresICloudMFA: (state, action) => {
      state.requiresICloudMFA = action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const { setOnline, setLoggedIn, setAuthToken, setRequiresICloudMFA } = appSlice.actions;

export default appSlice.reducer;
