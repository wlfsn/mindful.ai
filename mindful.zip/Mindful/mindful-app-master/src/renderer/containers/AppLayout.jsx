import { LogoutOutlined, UserOutlined, WechatOutlined } from '@ant-design/icons';
import { Button, Layout, Menu, theme, Typography, Row, Col } from 'antd';
import React, { useEffect } from 'react';
import { HashRouter as Router, Link, Route, Routes } from "react-router-dom";
import Chat from './Chat';
import Profile from './Profile';

import { useDispatch } from "react-redux";

const { Title } = Typography;
const { Header, Content, Footer, Sider } = Layout;

import './AppLayout.scss';


const items = [
  { key: '1', icon: <UserOutlined />, label: <Link to="/">Profile</Link>, link: '/' },
  { key: '2', icon: <WechatOutlined />, label: <Link to="/chat">Chat</Link>, link: '/chat' }
];

function AppLayout() {
  const dispatch = useDispatch();

  useEffect(() => {

  }, [dispatch]);

  const logout = () => {
    window.electron.ipcRenderer.invoke('logout');
  };

  const {
    token: { colorBgContainer, colorBgLayout },
  } = theme.useToken();

  return (
    <Router>
      <Layout hasSider className="app-layout" theme={"light"}>
        <Sider theme={"light"} className="app-layout__sider">
          <Title level={5} className="app-layout__sider__title">Mindful</Title>
          <Menu mode="inline" defaultSelectedKeys={['1']} items={items} theme={"light"} />
        </Sider>
        <Layout className="app-layout__site-layout" theme={"light"}>
          <Header className="app-layout__site-layout__header" theme={"light"} style={{background: colorBgContainer }}>
            <Row justify="end" align="middle">
              <Col>
                <Button shape="circle" icon={<LogoutOutlined />} onClick={logout} />
              </Col>
            </Row>
          </Header>
          <Content className="app-layout__site-layout__content" theme={"light"} style={{background: colorBgContainer}}>
            <div className="app-layout__site-layout__content__inner">
              <Routes>
                <Route exact path="/" element={<Profile />} />
                <Route path="/chat" element={<Chat />} />
              </Routes>
            </div>
          </Content>
          <Footer className="app-layout__site-layout__footer">
            Mindful ©2023 All rights reserved.
          </Footer>
        </Layout>
      </Layout>
    </Router>
  );
}

export default AppLayout;
