import React, {useEffect, useState} from 'react';
import { useSelector } from 'react-redux';
import { Typography, Col, Row, Card, Avatar, Space, Input, Button } from 'antd';
import { UserOutlined } from '@ant-design/icons';

const { Title, Text } = Typography;
const { TextArea } = Input;

const Profile = () => {
  const user = {
    username: "veemex",
    email: "tcm.mihai@gmail.com",
    description: "Example description",
    hobbies: [
    ]
  }


  const [appleEmail, setAppleEmail] = useState('');
  const [applePassword, setApplePassword] = useState('');

  useEffect(() => {
    setAppleEmail(localStorage.getItem('appleEmail'));
    setApplePassword(localStorage.getItem('applePassword'));
  }, []);


  const handleAppleEmail = (value) => {
    setAppleEmail(value);
  }

  const handleApplePassword = (value) => {
    setApplePassword(value);
  }

  //@TODO: save apple credentials to keytar and retrieve them on app start
  const handleAppleSave = () => {
    console.log('onClick')
    console.log(appleEmail)
    console.log(applePassword)

    localStorage.setItem('appleEmail', appleEmail);
    localStorage.setItem('applePassword', applePassword);
  }



  const handleDescriptionChange= (event) => {
    console.log(event.target.value);
  }


  return (
    <div>
      <div style={{margin: "16px"}}>
       <Title level={2}>Profile</Title>
      <Row gutter={[16, 16]}>
        <Col span={24}>
          <Card>
            <Row>
              <Col span={6}>
                <Space direction="vertical" size="middle" align="start">
                  <Avatar size={64} icon={<UserOutlined />} />
                  <Title level={4}>{user.username}</Title>
                  <Text>{user.email}</Text>
                </Space>
              </Col>
              <Col span={18}>
                <TextArea style={{height:'100%',resize:'none'}} allowClear={true} rows={4} placeholder="Write something about you..." maxLength={255} onChange={handleDescriptionChange} />
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
      </div>
      <div style={{margin: "16px"}}>
        <Title level={2}>Social Connections</Title>
        <Row gutter={[16, 16]} >
          <Col span={8}>
              <Card style={{ height:'260px'}} >
                <Space wrap>
                  <Title level={4}>Apple</Title>
                  <Input placeholder="Apple Id"  value={appleEmail} onChange={(event)=>handleAppleEmail(event.target.value)}/>
                  <Input.Password placeholder="App specific password" value={applePassword} onChange={(event)=>handleApplePassword(event.target.value)}/>
                  <Button type="primary" onClick={handleAppleSave}>Save</Button>
                </Space>
              </Card>
          </Col>
          <Col span={8}>
            <Card style={{ height:'200px'}} >

            </Card>
          </Col>
          <Col span={8}>
            <Card style={{ height:'200px'}} >

            </Card>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default Profile;
