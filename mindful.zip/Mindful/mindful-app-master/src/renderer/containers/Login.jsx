import React from 'react';
import { Form, Button, Card, Typography } from 'antd';
import './LoginForm.scss';

const { Title } = Typography;

const LoginForm = ({handleLogin}) => {
  const onFinish = async (values) => {
    await handleLogin();
    // Implement your authentication logic here
  };

  return (
    <div className="login-form">
      <Card className="login-form__card">
        <Title level={2}>Mindful</Title>

        <Form
          name="login-form"
          onFinish={onFinish}
          layout="vertical"
          initialValues={{ remember: true }}
          className="login-form__form"
        >
          <Form.Item className="login-form__form-item">
            <Button type="primary" htmlType="submit">
              Login
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default LoginForm;
