import React, {useCallback, useEffect} from 'react';
import {useSelector} from "react-redux";
import {useState} from "react";
import Login from "../Containers/Login";

const AuthProvider = ({ children }) => {

  const [loggedIn, setLoggedIn] = useState(false);


  useEffect(() => {
    let removeLoginListener;
    let removeLogoutListener;

    async function initializeAuthProvider() {
      removeLoginListener = window.electron.ipcRenderer.on('login', (event, arg) => {
        setLoggedIn(true);
      });

      removeLogoutListener = window.electron.ipcRenderer.on('logout', (event, arg) => {
        setLoggedIn(false);
      });

      try {
        const authToken = await window.electron.ipcRenderer.invoke('getToken');
        console.log('authToken', authToken);
        if (authToken) {
          setLoggedIn(true);
        }
      } catch (error) {
        console.error("Error while getting the token:", error);
      }
    }

    initializeAuthProvider().catch(error => console.error("Error while initializing the auth provider:", error));

    return () => {
      removeLoginListener();
      removeLogoutListener();
    }
  }, []);

  const handleLogin = async () => {
    const authToken = await window.electron.ipcRenderer.invoke('getToken' );
    console.log('authToken', authToken);
    if (authToken) {
      setLoggedIn(true);
    }
  }

  return (
    <div
    style={{
      position: 'relative',
      display: 'flex',
      width: '100%',
      height: '100%',
    }}
    >
      {loggedIn ? children : <Login handleLogin={handleLogin} />}

    </div>
  );
};

export default AuthProvider;

