// For JS use require() instead
import { auth0Login } from 'electron-auth0-login';

// Only import this directly into your main process
// For the rendering process, use electron.remote.require()

export default auth0Login({
  // Get these values from your Auth0 application console
  auth0: {
    audience: 'https://quantumbrowse.eu.auth0.com/api/v2/',
    clientId: 'pPxwaNae0bCYCx9nvRfssZh0jppqlVKK',
    domain: 'quantumbrowse.eu.auth0.com',
    scopes: '',
  },
  login:{
    authorizeParams: {
      access_type: 'offline',
      approval_prompt: 'force',
      // connection_scope: "https://www.googleapis.com/auth/calendar.events.readonly",
    }

  }
});
