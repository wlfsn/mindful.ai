/* eslint import/no-unresolved: off, import/no-self-import: off */

module.exports = require('./webpack.config.renderer.dev').default;
